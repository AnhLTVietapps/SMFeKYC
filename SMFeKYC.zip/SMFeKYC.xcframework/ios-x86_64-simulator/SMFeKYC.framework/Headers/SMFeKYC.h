//
//  SMFeKYC.h
//  SMFeKYC
//
//  Created by Anh Le on 2/26/21.
//

#import <Foundation/Foundation.h>

//! Project version number for SMFeKYC.
FOUNDATION_EXPORT double SMFeKYCVersionNumber;

//! Project version string for SMFeKYC.
FOUNDATION_EXPORT const unsigned char SMFeKYCVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SMFeKYC/PublicHeader.h>


